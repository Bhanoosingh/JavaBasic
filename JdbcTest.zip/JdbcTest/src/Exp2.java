import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Exp2 {

	public static void main(String[] args)throws IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Student id:-");
		int sid=Integer.parseInt(br.readLine());
		System.out.println("Enter Student Name:-");
		String sname=br.readLine();
		
		int x=DBConfig.executeUpdate("insert into student values("+sid+",'"+sname+"')");
		
		if(x>=0)
		{
			System.out.println("Statment Executed!");
		}
		else
		{
			System.out.println("Statment Terminated");
		}
		
		ResultSet rs=DBConfig.executeQuery("Select * from Student");
		try {
			while(rs.next())
			{
				System.out.println(rs.getInt("sid")+"\t"+rs.getString("sname"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
