import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Exp1 {

	public static void main(String[] args) {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		try {
		System.out.println("Enter Student id:-");
		int sid=Integer.parseInt(br.readLine());
		System.out.println("Enter Student Name:-");
		String sname=br.readLine();
		
		
			Class.forName("org.h2.Driver");
			Connection conn = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/JDBCTest1", "sa", "");
			Statement stmt=conn.createStatement();
			
			
			
			int x=stmt.executeUpdate("insert into student values("+sid+",'"+sname+"')");
			
			if(x>=0)
			{
				System.out.println("Statment Executed!");
			}
			else
			{
				System.out.println("Statment Terminated");
			}
			
			ResultSet rs=stmt.executeQuery("Select * from Student");
			while(rs.next())
			{
				System.out.println(rs.getInt("sid")+"\t"+rs.getString("sname"));
			}
		} catch (ClassNotFoundException | SQLException | NumberFormatException | IOException e) {
			e.printStackTrace();
		}

	}

}
